# KE-PPRA-IT-2022-04 Seed Package Skeleton

This folder is the starter import package for the PPRA Standard Tender Document for Procurement of Information Technology, DOC. 10.

## Status

- Package status: `SKELETON_ONLY`
- Activation allowed: `false`
- Intended lifecycle state after import: `DRAFT`
- Fixture import policy: `DO_NOT_IMPORT_BY_DEFAULT`

The files are valid JSON starter modules. They are designed for progressive population from the official IT STD extraction process. They are not a complete legal extraction and must not be activated as a production STD until full source extraction, source traceability, review, smoke tests, and approval are complete.

## Core rule

The official IT STD remains the master. The NSSF ERP tender fixture is included only to test whether the package can support a real ERP tender instance without contaminating the master template.

## Import posture

An importer should accept this package into `DRAFT` or `STRUCTURING` state only and must reject activation while `activation_allowed=false` in `manifest.json`.
