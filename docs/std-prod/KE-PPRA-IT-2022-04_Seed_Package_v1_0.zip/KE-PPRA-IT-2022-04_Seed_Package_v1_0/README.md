# KE-PPRA-IT-2022-04 Seed Package v1.0

This is a full-extraction candidate package for the KenTender STD Engine read model.

- Package ID: `KE-PPRA-IT-2022-04`
- Initial lifecycle state: `DRAFT`
- Activation allowed: `false`
- Quality: `FULL_EXTRACTION_CANDIDATE_REQUIRES_HUMAN_REVIEW`

## What changed from v0.2

- Added full extracted text candidates for ITT/GCC clauses.
- Added `source_text_hash` and `normalized_text_hash` for extracted clause text.
- Added source line anchors and official source file hashes.
- Included official DOC/PDF source files under `source_files/`.
- Added `extraction/full_clause_text_extraction_report.json`.
- Added `validation/validation_expectations.json`.
- Added `tests/full_extraction_smoke_tests.json`.

## Activation warning

This package must import as DRAFT only. It is not activatable until PDF page anchors, legal text fidelity, form/evaluation/render coverage, and smoke contracts pass human review.
