# KE-PPRA-IT-2022-04 Seed Package v1.0

Generated: 2026-07-10T12:07:33.494066+00:00

Status: `FULL_EXTRACTION_CANDIDATE_REQUIRES_HUMAN_REVIEW`.

This package supersedes v0.2 as the next extraction candidate. It patches the v0.2 package with machine-extracted full legal text for the 93 ITT/GCC clause records, normalized text hashes, source line anchors, official source document hashes, source files, validation expectations, and full-extraction smoke tests.

Important limitation: PDF page-level anchors are not claimed as legally verified in this generated candidate. Source line anchors and text hashes are present; page verification and legal/procurement review must still be completed before activation.
