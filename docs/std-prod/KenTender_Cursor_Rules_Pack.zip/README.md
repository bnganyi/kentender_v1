# KenTender Cursor Rules Pack

Copy the `.cursor/rules/*.mdc` files into the root of the KenTender repository.

Recommended usage:

1. Keep these rules committed to the repository.
2. Before each implementation task, give Cursor one bounded task and the relevant context documents only.
3. Require Cursor to produce a plan before editing files.
4. Require tests, smoke-contract checks, and `docs/MODULE_STATUS.md` updates before accepting a task.
5. Do not ask Cursor to implement broad modules in one prompt.

The rules intentionally protect the STD Engine from shortcuts that would compromise legal traceability, lifecycle governance, immutability, auditability, and future support for multiple Standard Tender Documents.
