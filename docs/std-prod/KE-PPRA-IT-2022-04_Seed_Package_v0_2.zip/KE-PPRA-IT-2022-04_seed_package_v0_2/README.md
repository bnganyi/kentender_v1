# KE-PPRA-IT-2022-04 Seed Package v0.2

This package is a reconciled draft seed package for the Kenya PPRA Standard Tender Document for Procurement of Information Technology.

Status: **Draft only. Not legally activatable.**

v0.2 reconciles the original skeleton package against extraction passes 1-5:

1. Sections, source anchors, and locked clause registers.
2. TDS, SCC, parameter dictionary, and rules.
3. Evaluation, qualification, tendering forms, and price schedule schemas.
4. Procuring Entity requirements, technical requirements, implementation schedule, and system inventory schemas.
5. Contract conditions, contract forms, acceptance certificates, change orders, and contract carry-forward schemas.

## Import policy

- Import allowed only into `DRAFT` or `STRUCTURING` state.
- Activation must be blocked.
- Fixture data under `fixtures/nssf_erp` must not be imported by default.
- Full legal and procurement review is mandatory before activation.

Generated at: 2026-07-07T20:59:01.573879+00:00
