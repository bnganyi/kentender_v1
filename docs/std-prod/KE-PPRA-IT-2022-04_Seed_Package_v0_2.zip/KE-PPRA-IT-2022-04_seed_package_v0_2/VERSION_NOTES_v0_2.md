# Version Notes - v0.2

## Changed from skeleton

- Manifest upgraded to reconciled draft v0.2.
- Source documents and hashes added.
- Section anchors reconciled to official source ranges.
- ITT and GCC clause title registers expanded.
- TDS/SCC parameters expanded.
- Rule catalog expanded across tender configuration, requirements, evaluation, pricing, contract, and addendum handling.
- Tendering forms, form fields, evidence requirements, price schedules, technical evaluation, requirement composer, implementation schedule, system inventory, and contract schemas expanded.
- NSSF ERP tender represented as calibration-only fixture.
- Smoke tests expanded.

## Remaining blockers

- Verbatim legal text extraction and clause text hashes.
- Paragraph-level source anchors.
- Full render templates.
- Final legal/procurement review.
- Target-system import dry-run and validation execution.
