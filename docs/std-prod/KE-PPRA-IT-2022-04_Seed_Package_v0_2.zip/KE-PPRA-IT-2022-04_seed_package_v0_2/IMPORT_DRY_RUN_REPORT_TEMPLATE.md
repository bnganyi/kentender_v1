# Import Dry-Run Report Template

## Package
- Package code: KE-PPRA-IT-2022-04
- Draft version: 0.2.0
- Import target environment:
- Import date/time:
- Operator:

## Expected result
- Package imports into Draft/Structuring.
- Package cannot activate.
- Fixture data is not imported unless test mode is enabled.

## Checks
| Check | Expected | Actual | Result |
|---|---|---|---|
| Manifest JSON valid | Pass |  |  |
| All JSON files valid | Pass |  |  |
| Required folders present | Pass |  |  |
| Source hashes present | Pass |  |  |
| Activation blocked | Pass |  |  |
| Fixture excluded by default | Pass |  |  |
| Smoke test definitions loaded | Pass |  |  |

## Findings

## Decision
- [ ] Accept as draft import
- [ ] Reject and fix package
