# IT Tender Wizard Complete Screen Registry v4

**Purpose:** Prevent missing screens, naming drift, and confusion between application surfaces, configuration steps, and workflow gates.

**Status:** Active registry. Supersedes v3 status table where detailed specs have now been created for UI-M01 and UI-01.

---

## 1. Application Surfaces

| ID | Exact user-facing name | Surface type | Required? | Current spec status |
|---|---|---|---:|---|
| UI-00 | IT Tender Configurations Dashboard | Application screen | Yes | Draft exists; audit against v4 after UI-01 is accepted |
| UI-M01 | Create IT Tender Configuration | Modal | Yes | Revised v4 spec created |
| UI-01 | Tender Configuration Home | Application screen | Yes | Revised v4 spec created |

---

## 2. Numbered Configuration Steps

Only these are configuration steps.

| ID | Exact user-facing name | Required? | Current spec status | Notes |
|---|---|---:|---|---|
| CFG-01 | Tender Profile | Yes | Draft exists; must be audited against v4 | First configuration step |
| CFG-02 | Tender Data Sheet | Yes | Draft exists; must be audited against v4 | TDS values only |
| CFG-03 | IT Requirements | Yes | Draft exists; must be audited against v4 | Must not include scoring, pricing, or contract administration |
| CFG-04 | Implementation Schedule | Yes | Draft exists; must be audited against v4 | Delivery plan only; no project execution |
| CFG-05 | System Inventory & Bidder Background | Yes | Missing detailed spec | Must cover Sections VIII and IX |
| CFG-06 | Price Schedule | Yes | Missing detailed spec | Price forms and pricing structure only |
| CFG-07 | Evaluation Setup | Yes | Missing detailed spec | Criteria/scoring only, not actual evaluation |
| CFG-08 | Forms & Evidence | Yes | Missing detailed spec | All non-price Section IV forms/evidence |
| CFG-09 | Contract Values | Yes | Missing detailed spec | SCC and contract-facing values |

---

## 3. Workflow Gates / Views

These are required functions, but they are not configuration steps.

| ID | Exact user-facing name | Surface type | Required? | Current spec status | Notes |
|---|---|---|---:|---|---|
| WF-01 | Readiness Report | Workflow report/view | Yes | Missing detailed spec | Opened after Run Readiness Check |
| WF-02 | Review Workspace | Workflow task/view | Yes | Missing detailed spec | Reviewer-focused; not a configuration form |
| WF-03 | Tender Document Preview | Preview view | Yes | Missing detailed spec | Read-only generated package preview |
| WF-04 | Publication Handoff | Handoff confirmation/view | Yes | Missing detailed spec | Marks package ready for Tender Management; does not publish |

---

## 4. Canonical Display in UI-01 Tender Configuration Home

### Configuration Steps

1. Tender Profile
2. Tender Data Sheet
3. IT Requirements
4. Implementation Schedule
5. System Inventory & Bidder Background
6. Price Schedule
7. Evaluation Setup
8. Forms & Evidence
9. Contract Values

### Completion & Handoff

- Readiness Check
- Review Status
- Tender Document Preview
- Publication Handoff

Do not show Validation, Review & Approval, Final Preview, or Publication Readiness as configuration cards.

---

## 5. Required Work Order

Continue in this order:

1. Review and accept UI-M01 — Create IT Tender Configuration.
2. Review and accept UI-01 — Tender Configuration Home.
3. Audit/rewrite UI-00 Dashboard against v4.
4. Audit/rewrite CFG-01 Tender Profile against v4.
5. Audit/rewrite CFG-02 Tender Data Sheet against v4.
6. Audit/rewrite CFG-03 IT Requirements against v4.
7. Audit/rewrite CFG-04 Implementation Schedule against v4.
8. Draft CFG-05 System Inventory & Bidder Background.

Do not proceed to CFG-05 until UI-M01 and UI-01 are accepted, because those surfaces control naming, sequencing, and entry rules for all later screens.
